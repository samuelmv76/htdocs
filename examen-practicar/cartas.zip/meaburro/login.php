<?php // login.php
$hn = 'localhost';
$db = 'cartas';
$un = 'root';
$pw = '';
?>